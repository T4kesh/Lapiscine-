-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 21, 2012 at 09:01 AM
-- Server version: 5.5.28
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bibliotheque`
--

-- --------------------------------------------------------

--
-- Table structure for table `auteur`
--

CREATE TABLE IF NOT EXISTS `auteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL DEFAULT '',
  `prenom` varchar(50) NOT NULL DEFAULT '',
  `date_naissance` date NOT NULL DEFAULT '1000-01-01',
  `pays_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_auteur_pays1` (`pays_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `auteur`
--

INSERT INTO `auteur` (`id`, `nom`, `prenom`, `date_naissance`, `pays_id`) VALUES
(1, 'Kundera', 'Milan', '1947-08-24', 219),
(2, 'Mishima', 'Yukio', '1925-01-14', 113),
(3, 'Kafka', 'Franz', '1883-07-03', 219),
(4, 'Borges', 'Jorge Luis', '1899-08-08', 14),
(5, 'Cheng', 'François', '1929-08-30', 46),
(6, 'Dantec', 'Maurice G.', '1959-06-13', 78),
(7, 'Burroughs', 'William S.', '1914-02-05', 72),
(8, 'Orwell', 'George', '1903-06-25', 104),
(9, 'Huxley', 'Aldous', '1894-07-26', 184),
(10, 'Barthes', 'Roland', '1915-11-12', 78),
(11, 'Marx', 'Karl', '1818-05-05', 6),
(12, 'Coelho', 'Paulo', '1947-08-24', 34),
(13, 'Ionesco', 'Eugène', '1909-11-26', 78);

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE IF NOT EXISTS `genre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`id`, `libelle`) VALUES
(1, 'Indéterminé'),
(2, 'Noir / Science-Fiction'),
(3, 'Fiction'),
(4, 'Roman'),
(5, 'Essai'),
(6, 'Anticipation'),
(7, 'Policier'),
(8, 'Théâtre'),
(9, 'Tragédie'),
(10, 'Autre');

-- --------------------------------------------------------

--
-- Table structure for table `illustration`
--

CREATE TABLE IF NOT EXISTS `illustration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commentaire` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `illustration`
--

INSERT INTO `illustration` (`id`, `commentaire`) VALUES
(1, 'Commentaire sur la couverture du livre'),
(2, 'Commentaire sur la couverture du livre'),
(3, 'Commentaire sur la couverture du livre'),
(4, 'Commentaire sur la couverture du livre'),
(5, 'Commentaire sur la couverture du livre'),
(6, 'Commentaire sur la couverture du livre'),
(7, 'Commentaire sur la couverture du livre'),
(8, 'Commentaire sur la couverture du livre'),
(9, 'Commentaire sur la couverture du livre'),
(10, 'Commentaire sur la couverture du livre'),
(11, 'Commentaire sur la couverture du livre'),
(12, 'Commentaire sur la couverture du livre'),
(13, 'Commentaire sur la couverture du livre'),
(14, 'Commentaire sur la couverture du livre'),
(15, 'Commentaire sur la couverture du livre'),
(16, 'Commentaire sur la couverture du livre');

-- --------------------------------------------------------

--
-- Table structure for table `lecteur`
--

CREATE TABLE IF NOT EXISTS `lecteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `adresse` varchar(150) DEFAULT NULL,
  `code_postal` int(5) unsigned zerofill DEFAULT '33000',
  `date_naissance` date NOT NULL DEFAULT '1000-01-01',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `lecteur`
--

INSERT INTO `lecteur` (`id`, `nom`, `prenom`, `adresse`, `code_postal`, `date_naissance`) VALUES
(1, 'Amadio', 'Philippe', 'Avda. de la Constitución 2222', 50210, '1983-03-16'),
(2, 'Béal', 'Benjamin', 'Sierras de Granada 9993', 50210, '1984-12-19'),
(3, 'Bertrand', 'Grégory', 'Av. dos Lusíadas, 23', 50220, '1980-07-27'),
(4, 'Cazes', 'Xavier', 'Mataderos  2312', 50210, '1981-11-23'),
(5, 'Chevillot', 'Matthieu', '12, rue de Marmande', 44000, '1983-05-28'),
(6, 'Colas', 'Matthieu', '184, chaussée de Tournai', 59000, '1980-12-18'),
(7, 'Coutant', 'Maxime', 'Via Monte Bianco 34', 10100, '1981-04-24'),
(8, 'Daviau', 'Laurent', 'Jardim das rosas n. 32', 16750, '1984-06-19'),
(9, 'De La Morinerie', 'Rémy', 'Av. dos Lusíadas, 23', 50210, '1981-11-12'),
(10, 'Delrio', 'Patrick', 'Mataderos  2312', 50210, '1982-10-01'),
(11, 'Durandeau', 'David', '23 Tsawassen Blvd.', 28023, '1982-07-06'),
(12, 'Froger', 'Antoine', '35 King George', 13008, '1984-07-04'),
(13, 'Hariga', 'Céline', '24, place Kléber', 67000, '1983-08-19'),
(14, 'Larousse', 'Romain', '54, rue Royale', 44000, '1982-10-15'),
(15, 'Launay', 'Sébastien', 'Berliner Platz 43', 80805, '1981-06-25'),
(16, 'Lunardelli', 'Nicolas', 'Rambla de Cataluña, 23', 80220, '1981-06-23'),
(17, 'Marrot', 'Nicolas', 'Fauntleroy Circus', 52066, '1984-10-01'),
(18, 'Mazeau', 'David', 'C/ Romero, 33', 41101, '1983-10-15'),
(19, 'Pointeau', 'Emmanuel', 'Åkergatan 24', 28034, '1981-01-12'),
(20, 'Riera', 'Jordi', 'Sierras de Granada 9993', 50210, '1983-08-06'),
(21, 'Seguin', 'Siegfried', 'Rua Orós, 92', 28034, '1983-01-22'),
(22, 'Borrut', 'Florence', 'Hauptstr. 29', 15022, '1984-12-09'),
(23, 'Richard', 'Fabien', '15, rue René Dychoux', 50210, '1980-08-27'),
(24, 'Hoareau', 'Maxime', '60, chemin du Monteil', 33770, '1982-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `livre`
--

CREATE TABLE IF NOT EXISTS `livre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(13) NOT NULL DEFAULT '0',
  `titre` varchar(50) NOT NULL DEFAULT 'Aucun titre',
  `resume` text NOT NULL,
  `annee` year(4) NOT NULL DEFAULT '0000',
  `date_emprunt` date DEFAULT NULL,
  `auteur_id` int(11) NOT NULL,
  `lecteur_id` int(11) NOT NULL,
  `genre_id` int(11) NOT NULL,
  `illustration_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `titre` (`titre`),
  KEY `fk_livre_auteur` (`auteur_id`),
  KEY `fk_livre_lecteur1` (`lecteur_id`),
  KEY `fk_livre_genre1` (`genre_id`),
  KEY `fk_livre_illustration1` (`illustration_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `livre`
--

INSERT INTO `livre` (`id`, `isbn`, `titre`, `resume`, `annee`, `date_emprunt`, `auteur_id`, `lecteur_id`, `genre_id`, `illustration_id`) VALUES
(1, '2070370437', 'Villa vortex', 'Le 11 septembre 2001, l''inspecteur Kernal décroche son téléphone qui lui explose à la figure. Agonisant, Kernal remonte le temps, nous racontant les dix dernières années de son existence, cette décennie où le monde tel que nous le connaissons part en fumée.\r\nFraîchement débarqué à la police de Vitry après de brillantes études en sciences sociales, Kernal avait été confronté à une série de crimes horribles entre 1991 et 1993 : des corps de jeunes filles recouverts de composants électroniques retrouvés aux environs de centrales électriques et nucléaires. Comme si le tueur voulait faire de ses victimes des marionnettes dernier cri…\r\nNous retrouvons dans Villa Vortex tous les thèmes chers à l''auteur : serial killer technologique, décor urbain apocalyptique, drogues synthétiques, sous oublier l''inscription du récit dans la réalité sociale et politique : l''ex-Yougoslavie, l''Algérie, la délinquance en banlieues, les attentats du World Trade Center… Dans cette critique hallucinée de la décennie 1990 qui a vu fleurir en Europe la misère économique, la violence, l''insécurité généralisée et la haine, l''auteur dépeint une société gangrenée par un Mal qui devient de plus en plus absolu à mesure même qu''il se dévoile.\r\n          ', 2003, '2012-12-14', 6, 6, 2, 7),
(2, '2070370232', 'Le tumulte des flots', 'Une retranscription de Daphnis et Chloé au pays du soleil levant.\r\nUne intrigue hésitant entre cul-cul et gnangnan, sans aucun suspens ou rebondissement, avec des images si grossières qu''elles feraient honte même aux imprimeurs d''Epinal. Mais alors ? Pourquoi lire ce livre ? Bein, Parsqu''il est intéressant !\r\nRetranscription d''un mythe que peu d''entre nous ont effectivement lus mais qui est passé dans la connaissance inconsciente et collective : le jeune couple dont l''amour est rendu impossible pour des histoires de convenance et de fortune mais qui, à force de courage et de vertu finit par légitimer l''union. Une véritable propagande de bonne conduite pour les jeunes gens de tous les pays. Affligeant.\r\nNéanmoins, la retranscription de cette histoire dans une petite province japonaise des années 50 nous en apprend énormément sur le système de valeurs japonais si différent du nôtre. Toutes les images et caricatures y passant, ce document constitue une véritable " pierre de Rosette " pour qui souhaite se constituer un ABCdaire comportemental japonais.\r\nEn outre, Mishima dépeint fantastiquement les paysages de bord de mer du Japon. Il sait nous faire sentir le sable et les embruns et nous décrire les pensées simples ou tortueuses de ses habitants. De bonnes cartes postales très représentatives tant du paysage que des occupations et préoccupations des villageois.\r\n          ', 1969, '2012-12-14', 2, 6, 4, 2),
(3, '2070381056', 'La métamorphose (et autres récits)', 'Lorsque Gregor Samsa s''éveille, un matin, après des rêves agités, il est bel et bien métamorphosé. Doté d''une épaisse carapace d''où s''échappent de pitoyables petites pattes ! Lugubre cocasserie ? Hélas, ultime défense contre ceux qui, certes, ne sont pas des monstres mais de vulgaires parasites... Les siens. Père, mère, soeur, dont l''ambition est de l''éliminer après avoir contribué à l''étouffer... Ici, un homme se transforme en coléoptère monstrueux, là, un engin pervers tue avec application... Dans la colonie pénitentiaire, c''est l''expérimentation en direct. Une machine infernale s''acharne sur un soldat soumis. Une machinerie hors pair, digne d''un inventeur à l''imagination torturée !\r\n          ', 1980, '2012-12-14', 3, 5, 3, 3),
(4, '2070366146', 'Fictions', 'Sans doute y a-t-il du dilettantisme dans ces Fictions, jeux de l''esprit et exercices de style fort ingénieux. Pourtant, le pluriel signale d''emblée qu''il s''agit d''une réflexion sur la richesse foisonnante de l''imagination. Au nombre de dix-huit, ces contes fantastiques révèlent, chacun à sa manière, une ambition totalisante qui s''exprime à travers de nombreux personnages au projet démiurgique ou encore à travers La Bibliothèque de Babel, qui prétend contenir l''ensemble des livres, existants ou non.\r\nLa multitude d''univers parallèles et d''effets de miroir engendrent un "délire circulaire" vertigineux, une interrogation sur la relativité du temps et de l''espace. Dans quelle dimension sommes-nous ? Qui est ce "je" qui raconte l''invasion de la cité dans La Loterie de Babylone ? En mettant en vis-à-vis le Quichotte de Ménard et celui de Cervantès, lit-on la même chose ou bien la décision de redire suffit-elle à rendre la redite impossible ? \r\n          ', 1965, '2012-12-14', 4, 12, 3, 4),
(5, '2070411761', 'L''identité', 'Grinçant, ironique et cruel, ce récit de la vie d''un couple permet à l''écrivain de transformer une histoire somme toute banale, en un fait de société dont le titre fournit un écho. Véritable crise concernant la place que chacun tient par rapport à l''autre.\r\n          ', 1997, NULL, 1, 0, 4, 5),
(6, '2220050890', 'Le dialogue', 'Une fois n''est pas coutume : pour traiter du thème entre les cultures et les civilisations, la collection Proches Lointains accueille dans ce volume unique un seul auteur, François Cheng. Et qui pouvait mieux symboliser, incarner le pont entre le monde chinois et l''univers occidental que l''auteur du Dit du Tianyi? Récemment couronné du Grand Prix de la Francophonie décerné par l''Académie française, François Cheng, exilé de Chine et arrivé à Paris au cours de l''après-guerre, s''est illustré dans plus d''un genre littéraire : la poésie, l''art calligraphique, le roman. C''est son aventure linguistique et sa passion des mots et de la littérature française qu''il nous fait partager ici, en s''interrogeant aussi sur la dimension intérieure, personnelle du dialogue, au-delà de la seule fracture entre les deux cultures.\r\nEcrivain, François Cheng a notamment publié Le Dit de Tianyi (Albin Michel, 1998), Chu Ta (Phebus, 1999), Poésie chinoise (Albin Michel, 2000), D''où jaillit le chant (Phébus, 2000), Qui dira notre nuit (Arfuyen, 2001).\r\n          ', 2002, '2012-12-14', 5, 14, 5, 8),
(7, '2070417530', 'Babylon babies', 'Un mafieux sibérien collectionneur de missiles. Un officier du GRU corrompu et lecteur de Sun Tzu. Une jeune schizophrène serai-amnésique trimbalant une arme biologique révolutionnaire. Des scientifiques assumant leur rôle d''apprentis sorciers et prêts à transgresser la Loi. Une poignée de soldats perdus à l''autre bout du monde, se battant pour des causes sans espoir. Des sectes post millénaristes à l''assaut des Citadelles du savoir. Des gangs de bikers se livrant à une guerre sans merci à coups de lance-roquettes. De jeunes technopunks préparant l''Apocalypse. Un écrivain de science-Fiction à moitié fou prétendant recevoir des messages du futur. N''ayez pas peur.\r\n          ', 1999, '2012-12-14', 6, 20, 6, 9),
(8, '2070417535', 'Le ticket qui explosa', 'Après avoir achevé son opus magnus, le Festin nu, William S. Burroughs se lance dans une longue période expérimentale. Dans sa petite chambre du Beat Hotel de la rue Gît-le-Coeur, il crée un véritable laboratoire d''écriture. C''est dans ce laboratoire faustien que naît le projet d''une oeuvre ambitieuse et risquée qui prend la forme d''un triptyque. Le premier volet, la Machine molle, paraît en 1961. Les deux suivants, le Ticket qui explosa et Nova Express sont écrits entre 1961 et 1964. A propos de la Trilogie, Burroughs affirme : " Je tente de créer une mythologie nouvelle pour l''ère spatiale. Je sens que les vieilles mythologies sont définitivement brisées et ne sont pas adaptées au temps présent. " Norman Mailer y voit une vision de l''Enfer, " un Enfer qui peut-être nous attend, produit final et apogée de la révolution scientifique ". Marshall MacLuhan y ressent une volonté de transcrire " en prose ce dont nous nous accommodons (...) comme un aspet banal de la vie à l''âge électronique. Si la vie collective doit être rendue sur le papier, il faut employer la méthode de non-histoire discontinue. " Burroughs, comme Dante et Milton, s''est employé à représenter la position de l''homme dans l''univers -, une position intenable, déchirante et absurde.\r\n          ', 1969, '2012-12-14', 7, 19, 6, 10),
(9, '207036822X', '1984', 'De tous les carrefours importants, le visage à la moustache noire vous fixait du regard. Il y en avait un sur le mur d''en face. Big Brother vous regarde, répétait la légende, tandis que le regard des yeux noirs pénétrait les yeux de Winston... Au loin, un hélicoptère glissa entre les toits, plana un moment, telle une mouche bleue, puis repartit comme une flèche, dans un vol courbe. C''était une patrouille qui venait mettre le nez aux fenêtres des gens. Mais les patrouilles n''avaient pas d''importance. Seule comptait la Police de la Pensée.', 1977, '2012-12-14', 8, 5, 6, 11),
(11, '2070378314', 'Le livre du rire et de l''oubli', 'L''exilé peut tout sauf oublier. C''est ainsi que Kundera, écrivain tchèque exilé en France, dans les sept chapitres apparemment disparates de ce roman, revient toujours au drame de sa Bohème natale. Selon Fernandez, on peut lire ce "vagabondage tendre et cocasse aux royaumes de l''amour et de la mort" sans se référer au contexte historique. Un très beau roman que Jacques Godbout qualifie de "difficile mais génial" et dont la tonalité majeure est un pessimisme tonique.\r\n          ', 2000, NULL, 1, 0, 4, 12),
(12, '2070407756', 'Les racines du mal', '"Andreas Schaltzmann s''est mis à tuer parce que son estomac pourrissait. Le phénomène n''était pas isolé, tant s''en faut. Cela faisait longtemps que les ondes cosmiques émises par les Aliens faisaient changer ses organes de place, depuis que les nazis et les habitants de Vega s''étaient installés dans ses quartiers." Andreas est un tueur et il le sait, mais quand on cherche à lui coller sur le dos des crimes qu''il n''a pas commis, du fond de sa clinique, il hurle.\r\n          ', 2002, '2012-12-14', 6, 17, 2, 13),
(13, '2020060604', 'Le plaisir du texte', 'Que savons-nous du texte ? La théorie, ces derniers temps, a commencé de répondre. Reste une question : que jouissons-nous du texte ? Cette question, il faut la poser, ne serait-ce que pour une raison tactique : il faut affirmer le plaisir du texte contre les indifférences de la science et le puritanisme de l''analyse idéologique; il faut affirmer la jouissance du texte contre l''aplatissement de la littérature à son simple agrément. Comment poser cette question? Il se trouve que le propre de la jouissance, c''est de ne pouvoir être dite. Il a donc fallu s''en remettre à une succession inordonnée de fragments facettes, touches, bulles, phylactères d''un dessin invisible : simple mise en scène de la question, rejeton hors-science de l''analyse textuelle.\r\n          ', 1999, '2012-12-14', 10, 4, 5, 14),
(14, '2264034076', 'Les portes de la perception', 'Par l''ingestion de mescaline, Aldous Huxley rejoint à son tour le paradis artificiel de Nerval et Baudelaire. Mais l''originalité de cette expérience tient à la volonté scientifique qui l''anime : en 1954, c''est sous contrôle médical que le romancier absorbe la drogue dans le but d''ouvrir, selon l''expression de William Blake, " les portes de la perception " et de " connaître, par l''intérieur, ce dont parlaient le visionnaire, le médium, et même le mystique, le miracle [...] de l''existence dans sa nudité, la réalité manifestée ". Outre ce récit initiatique, éponyme de l''ouvrage, sont rassemblés ici des essais qui témoignent d''une recherche spirituelle constante depuis La Philosophie éternelle (1945). A travers une culture syncrétique qui traite avec une même ferveur la pensée bouddhiste zen et le dogme catholique, se dessine le souci de mettre chacun sur la voie de l''illumination par la contemplation et le recueillement. Cette orientation donne aux réflexions de Huxley, sur le temps, l''art, le progrès et surtout la violence et la paix une dimension intemporelle. Cet essai a été suivi d''un autre qui le complète et l''enrichit, le ciel et l''enfer, réédité en 1999 aux éditions du Rocher.\r\n          ', 1954, NULL, 9, 0, 5, 15),
(16, '2080710028', 'Manifeste du parti communiste', 'Chef-d''oeuvre précoce de Marx et Engels, le Manifeste marque un tournant dans l''histoire du mouvement ouvrier : retraçant brièvement la genèse de la lutte des classes, Marx et Engels voulaient aussi doter la classe ouvrière d''un programme donnant des fondements scientifiques et durables à toute action révolutionnaire. Le résultat fut cette oeuvre brève, mondialement diffusée et dont la première édition vit le jour en 1848. Le présent volume comporte, outre le texte du Manifeste, un dossier qui inclut les préfaces des différentes éditions et des extraits de la correspondance entre Marx et Engels.\r\n          ', 1999, NULL, 11, 0, 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE IF NOT EXISTS `pays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_pays` char(2) NOT NULL DEFAULT '',
  `intitule` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `pays`
--

INSERT INTO `pays` (`id`, `code_pays`, `intitule`) VALUES
(1, 'AF', 'AFGHANISTAN'),
(2, 'ZA', 'AFRIQUE DU SUD'),
(3, 'AX', 'ÅLAND, ÎLES'),
(4, 'AL', 'ALBANIE'),
(5, 'DZ', 'ALGÉRIE'),
(6, 'DE', 'ALLEMAGNE'),
(7, 'AD', 'ANDORRE'),
(8, 'AO', 'ANGOLA'),
(9, 'AI', 'ANGUILLA'),
(10, 'AQ', 'ANTARCTIQUE'),
(11, 'AG', 'ANTIGUA-ET-BARBUDA'),
(12, 'AN', 'ANTILLES NÉERLANDAISES'),
(13, 'SA', 'ARABIE SAOUDITE'),
(14, 'AR', 'ARGENTINE'),
(15, 'AM', 'ARMÉNIE'),
(16, 'AW', 'ARUBA'),
(17, 'AU', 'AUSTRALIE'),
(18, 'AT', 'AUTRICHE'),
(19, 'AZ', 'AZERBAÏDJAN'),
(20, 'BS', 'BAHAMAS'),
(21, 'BH', 'BAHREÏN'),
(22, 'BD', 'BANGLADESH'),
(23, 'BB', 'BARBADE'),
(24, 'BY', 'BÉLARUS'),
(25, 'BE', 'BELGIQUE'),
(26, 'BZ', 'BELIZE'),
(27, 'BJ', 'BÉNIN'),
(28, 'BM', 'BERMUDES'),
(29, 'BT', 'BHOUTAN'),
(30, 'BO', 'BOLIVIE'),
(31, 'BA', 'BOSNIE-HERZÉGOVINE'),
(32, 'BW', 'BOTSWANA'),
(33, 'BV', 'BOUVET, ÎLE'),
(34, 'BR', 'BRÉSIL'),
(35, 'BN', 'BRUNÉI DARUSSALAM'),
(36, 'BG', 'BULGARIE'),
(37, 'BF', 'BURKINA FASO'),
(38, 'BI', 'BURUNDI'),
(39, 'KY', 'CAÏMANES, ÎLES'),
(40, 'KH', 'CAMBODGE'),
(41, 'CM', 'CAMEROUN'),
(42, 'CA', 'CANADA'),
(43, 'CV', 'CAP-VERT'),
(44, 'CF', 'CENTRAFRICAINE, RÉPUBLIQUE'),
(45, 'CL', 'CHILI'),
(46, 'CN', 'CHINE'),
(47, 'CX', 'CHRISTMAS, ÎLE'),
(48, 'CY', 'CHYPRE'),
(49, 'CC', 'COCOS (KEELING), ÎLES'),
(50, 'CO', 'COLOMBIE'),
(51, 'KM', 'COMORES'),
(52, 'CG', 'CONGO'),
(53, 'CD', 'CONGO, LA RÉPUBLIQUE DÉMOCRATIQUE DU'),
(54, 'CK', 'COOK, ÎLES'),
(55, 'KR', 'CORÉE, RÉPUBLIQUE DE'),
(56, 'KP', 'CORÉE, RÉPUBLIQUE POPULAIRE DÉMOCRATIQUE DE'),
(57, 'CR', 'COSTA RICA'),
(58, 'CI', 'CÔTE D''IVOIRE'),
(59, 'HR', 'CROATIE'),
(60, 'CU', 'CUBA'),
(61, 'DK', 'DANEMARK'),
(62, 'DJ', 'DJIBOUTI'),
(63, 'DO', 'DOMINICAINE, RÉPUBLIQUE'),
(64, 'DM', 'DOMINIQUE'),
(65, 'EG', 'ÉGYPTE'),
(66, 'SV', 'EL SALVADOR'),
(67, 'AE', 'ÉMIRATS ARABES UNIS'),
(68, 'EC', 'ÉQUATEUR'),
(69, 'ER', 'ÉRYTHRÉE'),
(70, 'ES', 'ESPAGNE'),
(71, 'EE', 'ESTONIE'),
(72, 'US', 'ÉTATS-UNIS'),
(73, 'ET', 'ÉTHIOPIE'),
(74, 'FK', 'FALKLAND, ÎLES (MALVINAS)'),
(75, 'FO', 'FÉROÉ, ÎLES'),
(76, 'FJ', 'FIDJI'),
(77, 'FI', 'FINLANDE'),
(78, 'FR', 'FRANCE'),
(79, 'GA', 'GABON'),
(80, 'GM', 'GAMBIE'),
(81, 'GE', 'GÉORGIE'),
(82, 'GS', 'GÉORGIE DU SUD ET LES ÎLES SANDWICH DU SUD'),
(83, 'GH', 'GHANA'),
(84, 'GI', 'GIBRALTAR'),
(85, 'GR', 'GRÈCE'),
(86, 'GD', 'GRENADE'),
(87, 'GL', 'GROENLAND'),
(88, 'GP', 'GUADELOUPE'),
(89, 'GU', 'GUAM'),
(90, 'GT', 'GUATEMALA'),
(91, 'GN', 'GUINÉE'),
(92, 'GW', 'GUINÉE-BISSAU'),
(93, 'GQ', 'GUINÉE ÉQUATORIALE'),
(94, 'GY', 'GUYANA'),
(95, 'GF', 'GUYANE FRANÇAISE'),
(96, 'HT', 'HAÏTI'),
(97, 'HM', 'HEARD, ÎLE ET MCDONALD, ÎLES'),
(98, 'HN', 'HONDURAS'),
(99, 'HK', 'HONG-KONG'),
(100, 'HU', 'HONGRIE'),
(101, 'UM', 'ÎLES MINEURES ÉLOIGNÉES DES ÉTATS-UNIS'),
(102, 'VG', 'ÎLES VIERGES BRITANNIQUES'),
(103, 'VI', 'ÎLES VIERGES DES ÉTATS-UNIS'),
(104, 'IN', 'INDE'),
(105, 'ID', 'INDONÉSIE'),
(106, 'IR', 'IRAN, RÉPUBLIQUE ISLAMIQUE D'''),
(107, 'IQ', 'IRAQ'),
(108, 'IE', 'IRLANDE'),
(109, 'IS', 'ISLANDE'),
(110, 'IL', 'ISRAËL'),
(111, 'IT', 'ITALIE'),
(112, 'JM', 'JAMAÏQUE'),
(113, 'JP', 'JAPON'),
(114, 'JO', 'JORDANIE'),
(115, 'KZ', 'KAZAKHSTAN'),
(116, 'KE', 'KENYA'),
(117, 'KG', 'KIRGHIZISTAN'),
(118, 'KI', 'KIRIBATI'),
(119, 'KW', 'KOWEÏT'),
(120, 'LA', 'LAO, RÉPUBLIQUE DÉMOCRATIQUE POPULAIRE'),
(121, 'LS', 'LESOTHO'),
(122, 'LV', 'LETTONIE'),
(123, 'LB', 'LIBAN'),
(124, 'LR', 'LIBÉRIA'),
(125, 'LY', 'LIBYENNE, JAMAHIRIYA ARABE'),
(126, 'LI', 'LIECHTENSTEIN'),
(127, 'LT', 'LITUANIE'),
(128, 'LU', 'LUXEMBOURG'),
(129, 'MO', 'MACAO'),
(130, 'MK', 'MACÉDOINE, L''EX-RÉPUBLIQUE YOUGOSLAVE DE'),
(131, 'MG', 'MADAGASCAR'),
(132, 'MY', 'MALAISIE'),
(133, 'MW', 'MALAWI'),
(134, 'MV', 'MALDIVES'),
(135, 'ML', 'MALI'),
(136, 'MT', 'MALTE'),
(137, 'MP', 'MARIANNES DU NORD, ÎLES'),
(138, 'MA', 'MAROC'),
(139, 'MH', 'MARSHALL, ÎLES'),
(140, 'MQ', 'MARTINIQUE'),
(141, 'MU', 'MAURICE'),
(142, 'MR', 'MAURITANIE'),
(143, 'YT', 'MAYOTTE'),
(144, 'MX', 'MEXIQUE'),
(145, 'FM', 'MICRONÉSIE, ÉTATS FÉDÉRÉS DE'),
(146, 'MD', 'MOLDOVA, RÉPUBLIQUE DE'),
(147, 'MC', 'MONACO'),
(148, 'MN', 'MONGOLIE'),
(149, 'MS', 'MONTSERRAT'),
(150, 'MZ', 'MOZAMBIQUE'),
(151, 'MM', 'MYANMAR'),
(152, 'NA', 'NAMIBIE'),
(153, 'NR', 'NAURU'),
(154, 'NP', 'NÉPAL'),
(155, 'NI', 'NICARAGUA'),
(156, 'NE', 'NIGER'),
(157, 'NG', 'NIGÉRIA'),
(158, 'NU', 'NIUÉ'),
(159, 'NF', 'NORFOLK, ÎLE'),
(160, 'NO', 'NORVÈGE'),
(161, 'NC', 'NOUVELLE-CALÉDONIE'),
(162, 'NZ', 'NOUVELLE-ZÉLANDE'),
(163, 'IO', 'OCÉAN INDIEN, TERRITOIRE BRITANNIQUE DE L'''),
(164, 'OM', 'OMAN'),
(165, 'UG', 'OUGANDA'),
(166, 'UZ', 'OUZBÉKISTAN'),
(167, 'PK', 'PAKISTAN'),
(168, 'PW', 'PALAOS'),
(169, 'PS', 'PALESTINIEN OCCUPÉ, TERRITOIRE'),
(170, 'PA', 'PANAMA'),
(171, 'PG', 'PAPOUASIE-NOUVELLE-GUINÉE'),
(172, 'PY', 'PARAGUAY'),
(173, 'NL', 'PAYS-BAS'),
(174, 'PE', 'PÉROU'),
(175, 'PH', 'PHILIPPINES'),
(176, 'PN', 'PITCAIRN'),
(177, 'PL', 'POLOGNE'),
(178, 'PF', 'POLYNÉSIE FRANÇAISE'),
(179, 'PR', 'PORTO RICO'),
(180, 'PT', 'PORTUGAL'),
(181, 'QA', 'QATAR'),
(182, 'RE', 'RÉUNION'),
(183, 'RO', 'ROUMANIE'),
(184, 'GB', 'ROYAUME-UNI'),
(185, 'RU', 'RUSSIE, FÉDÉRATION DE'),
(186, 'RW', 'RWANDA'),
(187, 'EH', 'SAHARA OCCIDENTAL'),
(188, 'SH', 'SAINTE-HÉLÈNE'),
(189, 'LC', 'SAINTE-LUCIE'),
(190, 'KN', 'SAINT-KITTS-ET-NEVIS'),
(191, 'SM', 'SAINT-MARIN'),
(192, 'PM', 'SAINT-PIERRE-ET-MIQUELON'),
(193, 'VA', 'SAINT-SIÈGE (ÉTAT DE LA CITÉ DU VATICAN)'),
(194, 'VC', 'SAINT-VINCENT-ET-LES GRENADINES'),
(195, 'SB', 'SALOMON, ÎLES'),
(196, 'WS', 'SAMOA'),
(197, 'AS', 'SAMOA AMÉRICAINES'),
(198, 'ST', 'SAO TOMÉ-ET-PRINCIPE'),
(199, 'SN', 'SÉNÉGAL'),
(200, 'CS', 'SERBIE-ET-MONTÉNÉGRO'),
(201, 'SC', 'SEYCHELLES'),
(202, 'SL', 'SIERRA LEONE'),
(203, 'SG', 'SINGAPOUR'),
(204, 'SK', 'SLOVAQUIE'),
(205, 'SI', 'SLOVÉNIE'),
(206, 'SO', 'SOMALIE'),
(207, 'SD', 'SOUDAN'),
(208, 'LK', 'SRI LANKA'),
(209, 'SE', 'SUÈDE'),
(210, 'CH', 'SUISSE'),
(211, 'SR', 'SURINAME'),
(212, 'SJ', 'SVALBARD ET ÎLE JAN MAYEN'),
(213, 'SZ', 'SWAZILAND'),
(214, 'SY', 'SYRIENNE, RÉPUBLIQUE ARABE'),
(215, 'TJ', 'TADJIKISTAN'),
(216, 'TW', 'TAÏWAN, PROVINCE DE CHINE'),
(217, 'TZ', 'TANZANIE, RÉPUBLIQUE-UNIE DE'),
(218, 'TD', 'TCHAD'),
(219, 'CZ', 'TCHÈQUE, RÉPUBLIQUE'),
(220, 'TF', 'TERRES AUSTRALES FRANÇAISES'),
(221, 'TH', 'THAÏLANDE'),
(222, 'TL', 'TIMOR-LESTE'),
(223, 'TG', 'TOGO'),
(224, 'TK', 'TOKELAU'),
(225, 'TO', 'TONGA'),
(226, 'TT', 'TRINITÉ-ET-TOBAGO'),
(227, 'TN', 'TUNISIE'),
(228, 'TM', 'TURKMÉNISTAN'),
(229, 'TC', 'TURKS ET CAÏQUES, ÎLES'),
(230, 'TR', 'TURQUIE'),
(231, 'TV', 'TUVALU'),
(232, 'UA', 'UKRAINE'),
(233, 'UY', 'URUGUAY'),
(234, 'VU', 'VANUATU'),
(235, 'VE', 'VENEZUELA'),
(236, 'VN', 'VIET NAM'),
(237, 'WF', 'WALLIS ET FUTUNA'),
(238, 'YE', 'YÉMEN'),
(239, 'ZM', 'ZAMBIE'),
(240, 'ZW', 'ZIMBABWE'),
(241, 'NS', '(NON SPECIFIE)');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auteur`
--
ALTER TABLE `auteur`
  ADD CONSTRAINT `fk_auteur_pays1` FOREIGN KEY (`pays_id`) REFERENCES `pays` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
